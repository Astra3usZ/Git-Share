import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

import javax.swing.JPanel;

public class CatchingFlashBall extends JPanel {
	int xcenter;
	int ycenter;
	int radius = 10;
	Random r = new Random();

	CatchingFlashBall() {
		this.setBackground(Color.BLACK);
	}

	public int nextInt(int max) {
		Random r = new Random();
		return r.nextInt(max);
	}

	public void paint(Graphics g) {
		g.setColor(Color.ORANGE);
		xcenter = r.nextInt(getWidth());
		ycenter = r.nextInt(getHeight());
		g.fillOval(xcenter, ycenter, radius * 2, radius * 2);
	}

	public class TimerListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}

	}

	public class Catcher implements MouseListener {
		int x1;
		int y1;
		
		double calculateDistance(int x1, int y1, int x2, int y2) {
			return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			x1 = e.getX();
			y1 = e.getY();
			if(this.calculateDistance(x1, y1, xcenter, ycenter) < radius) {
				return;
			}
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

	}
}
