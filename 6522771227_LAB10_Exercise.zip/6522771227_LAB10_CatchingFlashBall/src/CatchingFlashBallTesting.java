import javax.swing.JFrame;
import javax.swing.JPanel;

public class CatchingFlashBallTesting {
	public static void main(String[] args) {
		JFrame frame = new JFrame();

		JPanel CatchingFlashBall = new CatchingFlashBall();
		frame.add(CatchingFlashBall);

		frame.setTitle("My Catching FlashBall");
		frame.setSize(600, 400);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
