import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.*;

public class KeyboardGame extends JPanel implements ActionListener, KeyListener {
	char displayedChar;
	char typedChar = '?';
	static int score = 0;
	Timer timer = new Timer(2000, this);

	KeyboardGame() {
		
		this.addKeyListener(this);
	}

	public static char randomChar() {
		Random r = new Random();
		return (char) (r.nextInt(26) + 'A');
	}

	public void paint(Graphics g) {
		super.paintComponent(g);
		g.setFont(new Font("TimesRoman", Font.PLAIN, 45));
		g.drawString("Letter:", 75, 75);

		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				displayedChar = randomChar();
				repaint();
			}
		}, 1000, 1000);

		g.drawString(String.valueOf(displayedChar), 225, 75);
		g.drawString("You Typed", 75, 150);
		g.drawString(String.valueOf(typedChar), 375, 150);
		g.drawString("Your Score =", 75, 225);
		g.drawString(String.valueOf(score), 375, 225);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (typedChar == displayedChar) {
			score++;
		}
		repaint();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		typedChar = (char) (e.getKeyChar() & 0x5f);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}
