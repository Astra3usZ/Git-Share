import javax.swing.*;

public class KeyboardGameTesting {
	public static void main(String[] args) {
		JFrame frame = new JFrame();

		JPanel KeyboardGame = new KeyboardGame();
		frame.add(KeyboardGame);

		frame.setTitle("My Keyboard Game");
		frame.setSize(500, 300);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
